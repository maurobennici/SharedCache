namespace SharedCache.WinService
{

}
