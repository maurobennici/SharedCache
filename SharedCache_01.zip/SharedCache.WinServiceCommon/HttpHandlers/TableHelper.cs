﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SharedCache.WinServiceCommon.HttpHandlers
{
	/// <summary>
	/// Helper class used when building up the Html tables for display
	/// </summary>
	internal class TableHelper
	{
		public TableHelper()
		{
		}

		public static TableCell AddCell(TableRow rowToAddCellTo, string cellText)
		{
			TableCell cell = new TableCell();

			cell.Text = cellText;
			rowToAddCellTo.Cells.Add(cell);

			return cell;
		}

		public static TableCell AddCell(TableRow rowToAddCellTo, string cellText, string hyperLink)
		{
			TableCell cell = new TableCell();
			HtmlAnchor anchor = new HtmlAnchor();

			anchor.HRef = hyperLink;
			anchor.InnerText = cellText;
			cell.Controls.Add(anchor);

			rowToAddCellTo.Cells.Add(cell);

			return cell;
		}


		public static TableCell AddHeaderCell(TableRow rowToAddCellTo, string cellText)
		{
			TableHeaderCell cell = new TableHeaderCell();

			cell.Text = cellText;
			rowToAddCellTo.Cells.Add(cell);
			cell.HorizontalAlign = HorizontalAlign.Left;
			return cell;
		}

		public static Table CreateTable()
		{
			Table table = new Table();

			table.BorderStyle = BorderStyle.Solid;
			table.BorderWidth = Unit.Pixel(1);
			table.Width = Unit.Percentage(100);
			table.CellPadding = 0;
			table.CellSpacing = 0;
			return table;
		}
	}
}
