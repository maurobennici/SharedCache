﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace SharedCache.WinServiceCommon.HttpHandlers
{
	/// <summary>
	/// Summary description for ConfigSettings.
	/// </summary>
	public class HttpHandlersConfig
	{

		CacheViewSettings CacheViewSettings;
		SessionViewSettings sessionViewSettings;

		internal HttpHandlersConfig(HttpHandlersConfig parent)
		{
			if (parent != null)
			{
				CacheViewSettings = parent.CacheView;
				sessionViewSettings = parent.SessionView;
			}

		}

		internal void LoadValuesFromConfigurationXml(XmlNode node)
		{

			//Retreive the sessionView and CacheView config nodes
			//and create new config classes with the config xmlnode passed into their
			//ctor
			XmlNode sessionViewNode = node.SelectNodes("sessionView")[0];
			XmlNode CacheViewNode = node.SelectNodes("cacheView")[0];

			sessionViewSettings = new SessionViewSettings(sessionViewNode);

			CacheViewSettings = new CacheViewSettings(CacheViewNode);
		}

		/// <summary>
		/// Gets the setting for is the restriction on pages being bookmarkable On or Off by default
		/// </summary>
		public SessionViewSettings SessionView
		{
			get
			{
				return sessionViewSettings;
			}
		}

		/// <summary>
		/// Gets the setting for a Namespace to try and load Pages from
		/// </summary>
		public CacheViewSettings CacheView
		{
			get
			{
				return CacheViewSettings;
			}
		}
	}

	public class SessionViewSettings : StateViewerSettings
	{
		internal SessionViewSettings(XmlNode sessionViewConfigNode)
			: base(sessionViewConfigNode)
		{
		}
	}

	public class CacheViewSettings : StateViewerSettings
	{
		internal CacheViewSettings(XmlNode cacheViewConfigNode)
			: base(cacheViewConfigNode)
		{
		}
	}

	public abstract class StateViewerSettings
	{

		protected bool enabled;
		protected bool showViewDataLink;

		internal StateViewerSettings(XmlNode configNode)
		{
			if (configNode != null)
			{
				XmlAttributeCollection attribCol = configNode.Attributes;

				if (attribCol["enabled"].Value.ToLower() == "true")
				{
					enabled = true;
				}
				else
				{
					enabled = false;
				}

				if (attribCol["showViewDataLink"].Value.ToLower() == "true")
				{
					showViewDataLink = true;
				}
				else
				{
					showViewDataLink = false;
				}

			}
			else
			{
				enabled = false;
				showViewDataLink = false;
			}
		}

		public virtual bool Enabled
		{
			get
			{
				return enabled;
			}
		}

		public virtual bool ShowViewDataLink
		{
			get
			{
				return showViewDataLink;
			}
		}
	}
}
