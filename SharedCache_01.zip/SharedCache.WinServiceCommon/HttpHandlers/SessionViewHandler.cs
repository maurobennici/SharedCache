﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Web.UI.WebControls;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;

namespace SharedCache.WinServiceCommon.HttpHandlers
{
	/// <summary>
	/// This class is an HttpHandler and reports on ASP.NET Session State
	/// </summary>
	public class SessionViewHandler : IHttpHandler, IRequiresSessionState
	{
		private HttpContext m_context;
		private HttpRequest m_request;
		private HttpResponse m_response;
		private HtmlTextWriter m_writer;

		private Type[] m_altSerializationType;

		private HttpHandlersConfig m_HttpHandlerSettings;

		private string pageStyle;

		public SessionViewHandler()
		{
			pageStyle = @"<style> {background-color:white; color:black;	font: 10pt verdana, arial;}
				table {font: 10pt verdana, arial; cellspacing:0; 	cellpadding:0; 	margin-bottom:25}
				tr.subhead { background-color:cccccc;}
				th { padding:0,3,0,3 }
				th.alt { background-color:black; color:white; padding:3,3,2,3; }
				td { padding:0,3,0,3 }
				tr.alt { background-color:eeeeee }
				h1 { font: 24pt verdana, arial; margin:0,0,0,0}
				h2 { font: 18pt verdana, arial; margin:0,0,0,0}
				h3 { font: 12pt verdana, arial; margin:0,0,0,0}
				th a { color:darkblue; font: 8pt verdana, arial; }
				a { color:darkblue;text-decoration:none }
				a:hover { color:darkblue;text-decoration:underline; }
				div.outer { width:90%; margin:15,15,15,15}
				table.viewmenu td { background-color:006699; color:white; padding:0,5,0,5; }
				table.viewmenu td.end { padding:0,0,0,0; }
				table.viewmenu a {color:white; font: 8pt verdana, arial; }
				table.viewmenu a:hover {color:white; font: 8pt verdana, arial; }
				a.tinylink {color:darkblue; font: 8pt verdana, arial;text-decoration:underline;}
				a.link {color:darkblue; text-decoration:underline;}
				div.buffer {padding-top:7; padding-bottom:17;}
				.small { font: 8pt verdana, arial }
				table td { padding-right:20 } 
				table td.nopad { padding-right:5 }
			</style>";

			m_altSerializationType = new Type[19];

			m_altSerializationType[0] = typeof(String);
			m_altSerializationType[1] = typeof(Int32);
			m_altSerializationType[2] = typeof(Boolean);
			m_altSerializationType[3] = typeof(DateTime);
			m_altSerializationType[4] = typeof(Decimal);
			m_altSerializationType[5] = typeof(Byte);
			m_altSerializationType[6] = typeof(Char);
			m_altSerializationType[7] = typeof(Single);
			m_altSerializationType[8] = typeof(Double);
			m_altSerializationType[9] = typeof(Int16);
			m_altSerializationType[10] = typeof(Int64);
			m_altSerializationType[11] = typeof(UInt16);
			m_altSerializationType[12] = typeof(UInt32);
			m_altSerializationType[13] = typeof(UInt64);
			m_altSerializationType[14] = typeof(SByte);
			m_altSerializationType[15] = typeof(TimeSpan);
			m_altSerializationType[16] = typeof(Guid);
			m_altSerializationType[17] = typeof(IntPtr);
			m_altSerializationType[18] = typeof(UIntPtr);

		}

		private bool TypeIsInAlternativeSerializationList(Type type)
		{

			for (int i = 0; i <= (m_altSerializationType.Length - 1); i++)
			{
				if (type == m_altSerializationType[i])
				{
					return true;
				}
			}

			//Only would have got to here is the type was not found in the list of types
			//that go though the "alternative" serialization
			return false;
		}

		#region IHttpHandler Members

		/// <summary>
		/// Standard HttpHandler Entry point. Coordinate the displaying of the Session View
		/// </summary>
		/// <param name="context">The current HttpContext</param>
		public void ProcessRequest(HttpContext context)
		{

			//Only allow session viewing on requests that have originated locally
			if (Common.RequestIsLocal(context.Request) == false)
			{
				context.AddError(new ApplicationException("SessionView can only be accessed locally i.e. localhost"));
				return;
			}

			m_HttpHandlerSettings = (HttpHandlersConfig)context.GetConfig("sharedCache/httpHandlers");

			if (m_HttpHandlerSettings == null ||
					(m_HttpHandlerSettings.SessionView == null) ||
					(m_HttpHandlerSettings.SessionView.Enabled == false))
			{
				//Session View is not enabled fire exception
				context.AddError(new ApplicationException(@"SessionView is not enabled. See the sharedCache\httpHandlers\ section in your configuration file", null));
				return;
			}

			m_context = context;
			m_request = context.Request;
			m_response = context.Response;

			m_writer = new HtmlTextWriter(m_response.Output);

			m_writer.Write("<html>\r\n");

			//Write out Html head and style tags
			m_writer.Write("<head>\r\n");
			m_writer.Write(pageStyle);
			m_writer.Write("</head>\r\n");

			if (m_context.Session.Mode != SessionStateMode.Off)
			{
				if (context.Request.QueryString["Item"] == null)
				{
					//An item specific requets is NOT being made. Display the lot
					EnumerateAndDisplaySessionState();
				}
				else
				{
					//A session item specific request is being made. Try and display it
					DisplaySessionStateItem();
				}
			}
			else
			{
				//Session state is off
				DisplaySessionStateOff();
			}

			m_writer.Write("\r\n</body>\r\n</html>\r\n");

		}

		/// <summary>
		/// Gets the bool saying whether this HttpHandler is Reusable or not
		/// </summary>
		public bool IsReusable
		{
			get
			{
				return false;
			}
		}

		#endregion

		private void DisplaySessionStateOff()
		{
			Table sessionTable = TableHelper.CreateTable();

			//Table Header
			TableRow mainHeadingRow = new TableRow();
			sessionTable.Rows.Add(mainHeadingRow);

			TableHelper.AddHeaderCell(mainHeadingRow, "Session State is Off");

			sessionTable.RenderControl(m_writer);
		}

		private void EnumerateAndDisplaySessionState()
		{

			bool displayingObjectSize;

			Table sessionTable = TableHelper.CreateTable();

			//Table Header
			TableRow mainHeadingRow = new TableRow();
			sessionTable.Rows.Add(mainHeadingRow);

			TableCell mainHeading;

			if (m_context.Session.Mode == SessionStateMode.SQLServer ||
				m_context.Session.Mode == SessionStateMode.StateServer)
			{
				displayingObjectSize = true;
				mainHeading = TableHelper.AddHeaderCell(mainHeadingRow, "<h3><b>Session State Details including approximate item size</b></h3>");
				mainHeading.CssClass = "alt";
			}
			else
			{
				displayingObjectSize = false;
				mainHeading = TableHelper.AddHeaderCell(mainHeadingRow, "<h3><b>Session State Details</b></h3>");
			}

			mainHeading.ColumnSpan = 4;
			mainHeading.CssClass = "alt";

			TableRow secondaryHeadingRow = new TableRow();
			secondaryHeadingRow.CssClass = "subhead";
			sessionTable.Rows.Add(secondaryHeadingRow);

			TableCell headingRowCol1 = TableHelper.AddHeaderCell(secondaryHeadingRow, "Session Key");

			TableCell headingRowCol2 = TableHelper.AddHeaderCell(secondaryHeadingRow, "Object Type");

			if (displayingObjectSize == true)
			{
				TableCell headingRowCol3 = TableHelper.AddHeaderCell(secondaryHeadingRow, "Object Size (Serialized)");
			}
			else
			{
				//Make second column span 2
				headingRowCol2.ColumnSpan = 2;
			}

			TableCell headingRowCol4 = TableHelper.AddHeaderCell(secondaryHeadingRow, "View Data");

			bool alternatingRowToggle = false;
			TableRow dataRow;

			//Loop through all the session item keys 
			foreach (string sessionKey in m_context.Session.Keys)
			{

				dataRow = new TableRow();

				//Key column
				TableHelper.AddCell(dataRow, sessionKey);

				if (m_context.Session[sessionKey] != null)
				{
					//Get out of session
					Object sessionItem = m_context.Session[sessionKey];

					System.Type type = sessionItem.GetType();

					//Type column
					TableHelper.AddCell(dataRow, sessionItem.GetType().FullName);

					if (displayingObjectSize == true)
					{

						//Size column

						Stream alternativeSerializationStreamSessionKey = BinaryWrite(sessionKey);

						if (TypeIsInAlternativeSerializationList(sessionItem.GetType()) == true)
						{
							Stream alternativeSerializationStream = BinaryWrite(sessionItem);

							//Alt Serialization Size column
							TableHelper.AddCell(dataRow,
								Convert.ToDouble(alternativeSerializationStream.Length + alternativeSerializationStreamSessionKey.Length)
													/ Convert.ToDouble(1000) + " KB");

						}
						else
						{
							MemoryStream m;
							m = Common.BinarySerialize(sessionItem);

							TableHelper.AddCell(dataRow,
												Convert.ToDouble(m.Length + alternativeSerializationStreamSessionKey.Length)
																	/ Convert.ToDouble(1000) + " KB");
						}
					}
					else
					{
						// Make second column span 2 to make up for unused third col
						dataRow.Cells[1].ColumnSpan = 2;
					}

					//Data link column
					if (m_HttpHandlerSettings.SessionView.ShowViewDataLink == true)
					{
						StringWriter swTest = Common.XmlSerialize(sessionItem);

						if (swTest == null)
						{
							//Could not serialize the data in a human readable form using Xml
							TableHelper.AddCell(dataRow, "Data could not be serialized to Xml");
						}
						else
						{
							TableHelper.AddCell(dataRow, "Click to view data", "SessionView.axd?Item=" + sessionKey);
						}
					}
					else
					{
						TableHelper.AddCell(dataRow, "N/A");
					}
				}
				else
				{
					TableHelper.AddCell(dataRow, "N/A");

					if (displayingObjectSize == true)
					{
						TableHelper.AddCell(dataRow, "N/A");
					}
					else
					{
						dataRow.Cells[1].ColumnSpan = 3;
					}
				}

				if (alternatingRowToggle == true)
				{
					dataRow.CssClass = "alt";
				}

				alternatingRowToggle = alternatingRowToggle == Convert.ToBoolean(0);
				sessionTable.Rows.Add(dataRow);
			}

			sessionTable.RenderControl(m_writer);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="objectToWrite"></param>
		/// <returns></returns>
		private Stream BinaryWrite(object valueToWrite)
		{

			BinaryWriter writer = new BinaryWriter(new MemoryStream());

			System.Type valueType = valueToWrite.GetType();

			if (valueToWrite == null)
			{
				writer.Write(16);
				return writer.BaseStream;
			}

			if (valueType == m_altSerializationType[0])
			{
				writer.Write(1);
				writer.Write((String)valueToWrite);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[1])
			{
				writer.Write(2);
				writer.Write((Int32)valueToWrite);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[2])
			{
				writer.Write(3);
				writer.Write((Boolean)valueToWrite);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[3])
			{
				writer.Write(4);
				DateTime tempdateTime;
				tempdateTime = (DateTime)valueToWrite;
				writer.Write(tempdateTime.Ticks);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[4])
			{
				writer.Write(5);
				int[] decimalBits;
				decimalBits = Decimal.GetBits((Decimal)valueToWrite);
				int i = 0;
				while (i < 4)
				{
					writer.Write(decimalBits[i]);
					i++;
				}
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[5])
			{
				writer.Write(6);
				writer.Write((Byte)valueToWrite);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[6])
			{
				writer.Write(6);
				writer.Write((Char)valueToWrite);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[7])
			{
				writer.Write(8);
				writer.Write((Single)valueToWrite);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[8])
			{
				writer.Write(9);
				writer.Write((Double)valueToWrite);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[9])
			{
				writer.Write(10);
				writer.Write((Int16)valueToWrite);
				return writer.BaseStream;
			}
			if (valueToWrite == m_altSerializationType[10])
			{
				writer.Write(11);
				writer.Write((Int64)valueToWrite);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[11])
			{
				writer.Write(12);
				writer.Write((UInt16)valueToWrite);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[12])
			{
				writer.Write(13);
				writer.Write((UInt32)valueToWrite);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[13])
			{
				writer.Write(14);
				writer.Write((UInt64)valueToWrite);
				return writer.BaseStream;
			}

			if (valueType == m_altSerializationType[14])
			{
				writer.Write(10);
				writer.Write((SByte)valueToWrite);
				return writer.BaseStream;
			}

			if (valueType == m_altSerializationType[15])
			{
				writer.Write(16);
				TimeSpan timespanToWrite = (TimeSpan)valueToWrite;
				writer.Write(timespanToWrite.Ticks);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[16])
			{
				writer.Write(17);
				Guid guidToWrite = (Guid)valueToWrite;
				byte[] guidAsByteArray = guidToWrite.ToByteArray();
				writer.Write(guidAsByteArray);
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[17])
			{
				writer.Write(18);
				IntPtr intptrToWrite = (IntPtr)valueToWrite;
				if (IntPtr.Size == 4)
				{
					writer.Write(intptrToWrite.ToInt32());
					return writer.BaseStream;
				}
				writer.Write(intptrToWrite.ToInt64());
				return writer.BaseStream;
			}
			if (valueType == m_altSerializationType[18])
			{
				writer.Write(19);
				UIntPtr uintptrToWrite = (UIntPtr)valueToWrite;
				if (UIntPtr.Size == 4)
				{
					writer.Write(uintptrToWrite.ToUInt32());
					return writer.BaseStream;
				}
				writer.Write(uintptrToWrite.ToUInt64());
				return writer.BaseStream;
			}

			return writer.BaseStream;

		}

		private void DisplaySessionStateItem()
		{

			object sessionItem;

			//Get requested item from session state
			sessionItem = m_context.Session[m_request.QueryString["Item"]];

			Table sessionItemTable = TableHelper.CreateTable();

			//Table Header
			TableRow mainHeadingRow = new TableRow();
			sessionItemTable.Rows.Add(mainHeadingRow);

			TableCell mainHeading;

			mainHeading = TableHelper.AddHeaderCell(mainHeadingRow, "<h3><b>Session State Item</b></h3>");
			mainHeading.CssClass = "alt";
			mainHeading.ColumnSpan = 4;

			//Sub heading
			TableRow secondaryHeadingRow = new TableRow();
			secondaryHeadingRow.CssClass = "subhead";
			sessionItemTable.Rows.Add(secondaryHeadingRow);

			TableCell headingRowCol1 = TableHelper.AddHeaderCell(secondaryHeadingRow, "Session Item Key: " + m_request.QueryString["Item"]);

			//Explanation heading
			TableRow explanationHeadingRow = new TableRow();
			sessionItemTable.Rows.Add(explanationHeadingRow);

			TableHelper.AddCell(explanationHeadingRow, "The outer xml tags are a result of the Xml serialization used to render the item");

			TableRow dataRow;

			dataRow = new TableRow();

			if (sessionItem != null)
			{

				StringWriter swTest = Common.XmlSerialize(sessionItem);

				if (swTest == null)
				{
					//Could not serialize the data in a human readable form using Xml
					TableHelper.AddCell(dataRow, "Item was not viewable");
				}
				else
				{
					TableHelper.AddCell(dataRow, m_context.Server.HtmlEncode(swTest.ToString()));
				}
			}
			else
			{
				TableHelper.AddCell(dataRow, "Item is NULL in value");
			}

			sessionItemTable.Rows.Add(dataRow);

			sessionItemTable.RenderControl(m_writer);
		}
	}
}
