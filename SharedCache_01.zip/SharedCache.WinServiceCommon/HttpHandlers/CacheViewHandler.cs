﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Web;
using System.Collections;

namespace SharedCache.WinServiceCommon.HttpHandlers
{
	/// <summary>
	/// This class is an HttpHandler and reports on the ASP.NET Cache
	/// </summary>
	public class CacheViewHandler : IHttpHandler
	{

		private HttpContext m_context;
		private HttpRequest m_request;
		private HttpResponse m_response;
		private HtmlTextWriter m_writer;

		private HttpHandlersConfig m_HttpHandlerSettings;

		private string pageStyle;

		public CacheViewHandler()
		{
			pageStyle = @"<style> {background-color:white; color:black;	font: 10pt verdana, arial;}
				table {font: 10pt verdana, arial; cellspacing:0; 	cellpadding:0; 	margin-bottom:25}
				tr.subhead { background-color:cccccc;}
				th { padding:0,3,0,3 }
				th.alt { background-color:black; color:white; padding:3,3,2,3; }
				td { padding:0,3,0,3 }
				tr.alt { background-color:eeeeee }
				td.duplicate {background-color:red }
				h1 { font: 24pt verdana, arial; margin:0,0,0,0}
				h2 { font: 18pt verdana, arial; margin:0,0,0,0}
				h3 { font: 12pt verdana, arial; margin:0,0,0,0}
				th a { color:darkblue; font: 8pt verdana, arial; }
				a { color:darkblue;text-decoration:none }
				a:hover { color:darkblue;text-decoration:underline; }
				div.outer { width:90%; margin:15,15,15,15}
				table.viewmenu td { background-color:006699; color:white; padding:0,5,0,5; }
				table.viewmenu td.end { padding:0,0,0,0; }
				table.viewmenu a {color:white; font: 8pt verdana, arial; }
				table.viewmenu a:hover {color:white; font: 8pt verdana, arial; }
				a.tinylink {color:darkblue; font: 8pt verdana, arial;text-decoration:underline;}
				a.link {color:darkblue; text-decoration:underline;}
				div.buffer {padding-top:7; padding-bottom:17;}
				.small { font: 8pt verdana, arial }
				table td { padding-right:20 }
				table td.nopad { padding-right:5 }
			</style>";
		}

		#region IHttpHandler Members

		/// <summary>
		/// Standard HttpHandler Entry point. Coordinate the displaying of the Cache View
		/// </summary>
		/// <param name="context">The current HttpContext</param>
		public void ProcessRequest(HttpContext context)
		{

			if (Common.RequestIsLocal(context.Request) == false)
			{
				context.AddError(new ApplicationException("CacheView can only be accessed locally i.e. localhost"));
				return;
			}

			m_HttpHandlerSettings = (HttpHandlersConfig)context.GetConfig("sharedCache/httpHandlers");

			if (m_HttpHandlerSettings == null ||
					(m_HttpHandlerSettings.CacheView == null) ||
					(m_HttpHandlerSettings.CacheView.Enabled == false))
			{
				//Cache View is not enabled fire exception
				context.AddError(new ApplicationException(@"CacheView is not enabled. See the sharedCache/httpHandlers section in your configuration file", null));
				return;
			}

			m_context = context;
			m_request = context.Request;
			m_response = context.Response;

			m_writer = new HtmlTextWriter(m_response.Output);

			m_writer.Write("<html>\r\n");

			//Write out Html head and style tags
			m_writer.Write("<head>\r\n");
			m_writer.Write(pageStyle);
			m_writer.Write("</head>\r\n");

			if (context.Request.QueryString["Item"] == null)
			{
				//An item specific requets is NOT being made. Display the lot
				EnumerateAndDisplayCache();
			}
			else
			{
				//A cache item specific request is being made. Try and display it
				DisplayCacheItem();
			}

			m_writer.Write("\r\n</body>\r\n</html>\r\n");
		}

		public bool IsReusable
		{
			get
			{
				return false;
			}
		}

		#endregion

		private void DisplayCacheItem()
		{

			object cacheItem;

			//Get requested item from cache
			cacheItem = m_context.Cache[m_request.QueryString["Item"]];

			Table sessionItemTable = TableHelper.CreateTable();

			//Table Header
			TableRow mainHeadingRow = new TableRow();
			sessionItemTable.Rows.Add(mainHeadingRow);

			TableCell mainHeading;

			mainHeading = TableHelper.AddHeaderCell(mainHeadingRow, "<h3><b>Cache Item</b></h3>");
			mainHeading.CssClass = "alt";
			mainHeading.ColumnSpan = 4;

			//Sub heading
			TableRow secondaryHeadingRow = new TableRow();
			secondaryHeadingRow.CssClass = "subhead";
			sessionItemTable.Rows.Add(secondaryHeadingRow);

			TableCell headingRowCol1 = TableHelper.AddHeaderCell(secondaryHeadingRow, "Cache Item Key: " + m_request.QueryString["Item"]);

			//Explanation heading
			TableRow explanationHeadingRow = new TableRow();
			sessionItemTable.Rows.Add(explanationHeadingRow);

			TableHelper.AddCell(explanationHeadingRow, "The outer xml tags are a result of the Xml serialization used to render the item<BR><BR>");

			TableRow dataRow;

			dataRow = new TableRow();

			if (cacheItem != null)
			{

				StringWriter swTest = Common.XmlSerialize(cacheItem);

				if (swTest == null)
				{
					//Could not serialize the data in a human readable form using Xml
					TableHelper.AddCell(dataRow, "Item was not viewable");
				}
				else
				{
					TableHelper.AddCell(dataRow, m_context.Server.HtmlEncode(swTest.ToString()));
				}
			}
			else
			{
				TableHelper.AddCell(dataRow, "Item is NULL in value");
			}

			sessionItemTable.Rows.Add(dataRow);

			sessionItemTable.RenderControl(m_writer);
		}
		private void EnumerateAndDisplayCache()
		{

			Table cacheTable = TableHelper.CreateTable();

			//Table Header
			TableRow mainHeadingRow = new TableRow();
			cacheTable.Rows.Add(mainHeadingRow);

			TableCell mainHeading;

			mainHeading = TableHelper.AddHeaderCell(mainHeadingRow, "<h3><b>Cache Details</b></h3>");
			mainHeading.ColumnSpan = 3;
			mainHeading.CssClass = "alt";

			TableRow secondaryHeadingRow = new TableRow();
			secondaryHeadingRow.CssClass = "subhead";
			cacheTable.Rows.Add(secondaryHeadingRow);

			TableCell headingRowCol1 = TableHelper.AddHeaderCell(secondaryHeadingRow, "Cache Key");

			TableCell headingRowCol2 = TableHelper.AddHeaderCell(secondaryHeadingRow, "Cached Object Type");

			TableCell headingRowCol3 = TableHelper.AddHeaderCell(secondaryHeadingRow, "View Data");

			bool alternatingRowToggle = false;
			ArrayList enumeratedItems = new ArrayList();
			TableRow dataRow;

			foreach (DictionaryEntry cacheDictionaryItem in m_context.Cache)
			{
				dataRow = new TableRow();

				//Key column
				TableHelper.AddCell(dataRow, cacheDictionaryItem.Key.ToString());

				if (m_context.Cache[cacheDictionaryItem.Key.ToString()] != null)
				{

					//Get out of cache
					Object cacheObjectItem = m_context.Cache[cacheDictionaryItem.Key.ToString()];

					System.Type type = cacheObjectItem.GetType();

					//Type column
					TableHelper.AddCell(dataRow, cacheObjectItem.GetType().FullName);

				}
				else
				{
					//Type column
					TableHelper.AddCell(dataRow, "NULL");
				}

				//Data link column
				if (m_HttpHandlerSettings.CacheView.ShowViewDataLink == true)
				{
					StringWriter swTest = Common.XmlSerialize(cacheDictionaryItem.Value);

					if (swTest == null)
					{
						//Could not serialize the data in a human readable form using Xml
						TableHelper.AddCell(dataRow, "Data could not be serialized to Xml");
					}
					else
					{
						TableHelper.AddCell(dataRow, "Click to view data", "CacheView.axd?Item=" + cacheDictionaryItem.Key.ToString());
					}
				}
				else
				{
					TableHelper.AddCell(dataRow, "N/A");
				}

				if (alternatingRowToggle == true)
				{
					dataRow.CssClass = "alt";
				}

				alternatingRowToggle = alternatingRowToggle == Convert.ToBoolean(0);
				cacheTable.Rows.Add(dataRow);
			}

			cacheTable.RenderControl(m_writer);
		}
	}
}
