﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Xml;

namespace SharedCache.WinServiceCommon.HttpHandlers
{
	/// <summary>
	/// Summary description for CustomConfigHandler.
	/// </summary>
	public class HttpHandlersConfigHandler : IConfigurationSectionHandler
	{
		/// <summary></summary>
		public HttpHandlersConfigHandler()
		{
		}

		#region IConfigurationSectionHandler Members

		/// <summary>
		/// 
		/// </summary>
		/// <param name="parent"></param>
		/// <param name="configContext"></param>
		/// <param name="section"></param>
		/// <returns></returns>
		public object Create(object parent, object configContext, XmlNode section)
		{

			HttpHandlersConfig config = new HttpHandlersConfig((HttpHandlersConfig)parent);
			config.LoadValuesFromConfigurationXml(section);
			return config;

		}

		#endregion
	}
}
