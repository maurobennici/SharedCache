﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Web;

namespace SharedCache.WinServiceCommon.HttpHandlers 
{
	/// <summary>
	/// Summary description for Common.
	/// </summary>
	internal class Common
	{
		/// <summary>
		/// Check if curremt request originated locally
		/// </summary>
		/// <param name="request">The current HttpRequest</param>
		/// <returns>True if the request originated locally</returns>
		internal static bool RequestIsLocal(HttpRequest request)
		{

			if (request.UserHostAddress == "127.0.0.1" ||
				request.UserHostAddress == request.ServerVariables["LOCAL_ADDR"])
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// Serilaize object into a memory stream using Binary Serialization
		/// </summary>
		/// <param name="objectToSerialize">object to serialize</param>
		/// <returns></returns>
		internal static MemoryStream BinarySerialize(object objectToSerialize)
		{
			MemoryStream m = new MemoryStream();
			BinaryFormatter b = new BinaryFormatter();

			b.Serialize(m, objectToSerialize);

			return m;
		}

		/// <summary>
		/// Serialize object into StringWriter using XmlSerialization
		/// </summary>
		/// <param name="objectToSerialize">object to serialize</param>
		/// <returns></returns>
		internal static StringWriter XmlSerialize(object objectToSerialize)
		{


			try
			{
				XmlSerializer serializer = new XmlSerializer(objectToSerialize.GetType());

				System.IO.StringWriter writer = new System.IO.StringWriter();

				//This is used to remove the standard XMl namespaces from the serialized output
				//so as to make it easier to see in the browser output
				XmlQualifiedName[] dummyNamespaceName = new XmlQualifiedName[1];

				dummyNamespaceName[0] = new XmlQualifiedName();

				serializer.Serialize(writer, objectToSerialize, new XmlSerializerNamespaces(dummyNamespaceName));

				return writer;
			}
			//If we cannot serialize then we can't leave it at that
			catch (InvalidOperationException)
			{
				//Ignore This can happen when some objects are just not Serializable using XML serialization
			}
			catch (System.Runtime.Serialization.SerializationException)
			{
				//Ignore. This can happen when storing a set of custom objects in a collection.
				//The XmlSerializer will start to serialize the collection come across the custom objects
				//amd not know what to do. The use of custom serialization attributes will help the serializer.
			}
			catch (Exception ex)
			{
				string s = ex.Message;
			}

			//This will only be hit by a failed serialization execution
			return null;
		}
	}
}
