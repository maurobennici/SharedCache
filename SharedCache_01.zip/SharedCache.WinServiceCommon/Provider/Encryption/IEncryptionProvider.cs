﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharedCache.WinServiceCommon.Provider.Encryption
{
	public interface IEncryptionProvider
	{
		byte[] Encrypt(byte[] plainText);
		byte[] Decrypt(byte[] encryptedData);
	}
}
