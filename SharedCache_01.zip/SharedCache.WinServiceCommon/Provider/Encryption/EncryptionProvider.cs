﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace SharedCache.WinServiceCommon.Provider.Encryption
{
	internal class EncryptionProvider : IEncryptionProvider
	{
		// private static string hashSalt = "A sweet secret password";
		private static string hashSalt = Provider.Cache.IndexusDistributionCache.ProviderSection.ClientSetting.EncryptionProviderHashSalt;

		public byte[] Encrypt(byte[] plainText)
		{

			if (string.IsNullOrEmpty(hashSalt))
				return plainText;

			RijndaelManaged RijndaelCipher = new RijndaelManaged();
			byte[] Salt = Encoding.ASCII.GetBytes(hashSalt.Length.ToString());

			PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(hashSalt, Salt);
			ICryptoTransform Encryptor = RijndaelCipher.CreateEncryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16));
			MemoryStream memoryStream = new MemoryStream();
			CryptoStream cryptoStream = new CryptoStream(memoryStream, Encryptor, CryptoStreamMode.Write);

			// Start the encryption process.
			cryptoStream.Write(plainText, 0, plainText.Length);

			// Finish encrypting.
			cryptoStream.FlushFinalBlock();

			// Convert our encrypted data from a memoryStream into a byte array.
			byte[] CipherBytes = memoryStream.ToArray();

			// Close both streams.
			memoryStream.Close();
			cryptoStream.Close();

			return CipherBytes;
		}

		public byte[] Decrypt(byte[] encryptedData)
		{
			if (string.IsNullOrEmpty(hashSalt))
				return encryptedData;

			RijndaelManaged RijndaelCipher = new RijndaelManaged();

			byte[] Salt = Encoding.ASCII.GetBytes(hashSalt.Length.ToString());

			PasswordDeriveBytes SecretKey = new PasswordDeriveBytes(hashSalt, Salt);

			// Create a decryptor from the existing SecretKey bytes.
			ICryptoTransform Decryptor = RijndaelCipher.CreateDecryptor(SecretKey.GetBytes(32), SecretKey.GetBytes(16));
			MemoryStream memoryStream = new MemoryStream(encryptedData);

			// Create a CryptoStream. (always use Read mode for decryption).
			CryptoStream cryptoStream = new CryptoStream(memoryStream, Decryptor, CryptoStreamMode.Read);

			// Since at this point we don't know what the size of decrypted data
			// will be, allocate the buffer long enough to hold EncryptedData;
			// DecryptedData is never longer than EncryptedData.
			byte[] PlainText = new byte[encryptedData.Length];

			// Start decrypting.
			int DecryptedCount = cryptoStream.Read(PlainText, 0, PlainText.Length);

			memoryStream.Close();
			cryptoStream.Close();

			if (DecryptedCount == 0) return null;

			//get rid of extra
			var returnBytes = new List<byte>(PlainText);
			returnBytes.RemoveRange(DecryptedCount, returnBytes.Count - DecryptedCount);

			// Return decrypted data 
			return returnBytes.ToArray();
		}

	}
}
