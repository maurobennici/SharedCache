﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using SCCACHE = SharedCache.WinServiceCommon.Provider.Cache.IndexusDistributionCache;

namespace SharedCache.Testing
{
	/// <summary>
	/// Summary description for CachingSingleInstance
	/// </summary>
	[TestClass]
	public class CachingSingleInstance
	{
		public CachingSingleInstance()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region Additional test attributes
		/// <summary>
		/// Use ClassInitialize to run code before running the first test in the class
		/// </summary>
		/// <param name="testContext"></param>
		[ClassInitialize()]
		public static void CachingSingleInstanceInitialize(TestContext testContext) 
		{
			TestServerHelper.LoadServerAsConsole("singleInstance");
			// let the server be loaded
			System.Threading.Thread.Sleep(1500);
		}
		/// <summary>
		/// Use ClassCleanup to run code after all tests in a class have run
		/// </summary>
		[ClassCleanup()]
		public static void CachingSingleInstanceCleanup() 
		{
			TestServerHelper.UnLoadServerAsConsole();
		}
		#endregion

		[TestMethod]
		public void TestAddWithOverloads()
		{
			// create some data to add to cache.

			List<HelperObjects.SerializeAttribute.Person> data = new List<SharedCache.Testing.HelperObjects.SerializeAttribute.Person>()
      {
        new HelperObjects.SerializeAttribute.Person(){Salutation = "MR", FirstName = "Abcd", LastName = "Lmno", Age = 20},
        new HelperObjects.SerializeAttribute.Person(){Salutation = "MR", FirstName = "Efgh", LastName = "Pqrs", Age = 21},
        new HelperObjects.SerializeAttribute.Person(){Salutation = "MR", FirstName = "Ijkl", LastName = "tuvw", Age = 22}
      };
      // iterate over items and add to each person object an address
			foreach (var item in data)
      {
        item.Address = new List<SharedCache.Testing.HelperObjects.SerializeAttribute.Address>()
        {
          new HelperObjects.SerializeAttribute.Address(){ Country = "Switzerland", CountryCode = "CH", ZipCode = "8000", StreetNo = "223", Street = "Bahnhofstrasse" },
          new HelperObjects.SerializeAttribute.Address(){ Country = "United States of America", CountryCode = "US", ZipCode = "917", StreetNo = "10025", Street = "947 Amsterdam Ave" },
          new HelperObjects.SerializeAttribute.Address(){ Country = "Germany", CountryCode = "DE", ZipCode = "50000", StreetNo = "223", Street = "Gartenstrasse" }
        };
      }
			SCCACHE.SharedCache.Add("data", data);
			Assert.AreEqual(1, SCCACHE.SharedCache.GetAllKeys().Count);
			Assert.AreEqual(data, SCCACHE.SharedCache.Get("data"));
		}
	}
}
